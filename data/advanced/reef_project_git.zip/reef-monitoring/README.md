# Reef monitoring

Analysis of the coral transects of the three MPAs.

Run the scripts of `R/` in order: 01, 02, 03, 04.
