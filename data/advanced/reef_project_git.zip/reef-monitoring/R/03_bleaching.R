bleach_threshold <- 20   # changed after the meeting with the MPA managers
reef$severe <- reef$bleached_pct >= bleach_threshold
table(reef$year, reef$severe)
