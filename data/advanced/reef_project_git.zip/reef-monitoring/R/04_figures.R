library(ggplot2)
ggplot(reef, aes(factor(year), hard_coral, fill = zone)) + geom_boxplot()
ggsave("outputs/coral_by_year.png", width = 16, height = 9, units = "cm")
