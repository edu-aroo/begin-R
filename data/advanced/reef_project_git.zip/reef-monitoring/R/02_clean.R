reef <- merge(reef, sites, by = "site_id")
reef <- reef[!is.na(reef$hard_coral), ]
